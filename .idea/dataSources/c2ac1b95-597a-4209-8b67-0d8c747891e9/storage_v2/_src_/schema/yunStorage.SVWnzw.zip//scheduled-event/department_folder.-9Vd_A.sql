create definer = root@`%` event department_folder on schedule
    at '2019-09-19 21:10:15'
    enable
    do
    DELETE FROM department_folder where folder_statu = 0;

