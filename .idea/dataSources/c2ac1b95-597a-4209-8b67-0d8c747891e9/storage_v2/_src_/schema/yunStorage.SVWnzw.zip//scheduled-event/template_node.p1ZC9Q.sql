create definer = root@`%` event template_node on schedule
    at '2019-09-19 21:10:15'
    enable
    do
    DELETE FROM template_node where status = 0;

