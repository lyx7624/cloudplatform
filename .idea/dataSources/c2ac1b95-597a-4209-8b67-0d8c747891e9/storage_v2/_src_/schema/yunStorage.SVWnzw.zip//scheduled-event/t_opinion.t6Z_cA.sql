create definer = root@`%` event t_opinion on schedule
    at '2019-09-19 21:10:15'
    enable
    do
    DELETE FROM t_opinion where status = 0;

