create definer = root@`%` event project_folder on schedule
    at '2019-09-19 21:10:15'
    enable
    do
    DELETE FROM project_folder where folder_statu = 0;

