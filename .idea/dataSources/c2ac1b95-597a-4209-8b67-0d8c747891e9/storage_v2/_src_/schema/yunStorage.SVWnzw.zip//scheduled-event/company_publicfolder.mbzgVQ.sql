create definer = root@`%` event company_publicfolder on schedule
    at '2019-09-19 21:10:15'
    enable
    do
    DELETE FROM company_publicfolder where folder_statu = 0;

