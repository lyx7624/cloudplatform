create definer = root@`%` event process_node on schedule
    at '2019-09-19 21:10:15'
    enable
    do
    DELETE FROM process_node where status = 0;

