create definer = root@`%` event process_info on schedule
    at '2019-09-19 21:10:15'
    enable
    do
    DELETE FROM process_info where process_status = 0;

